Osi and Clp version that can be compiled with cmake

  * Osi (Open Solver Interface) provides an abstract base class to a generic linear programming (LP) solver, along with derived classes for specific solvers

  * Clp (Coin-or linear programming) is an open-source linear programming solver written in C++.

It provides a generic interface to solve Linear Programs.
Two solvers are accessible in this release:
  * Clp,
  * the mosek wrapper.
