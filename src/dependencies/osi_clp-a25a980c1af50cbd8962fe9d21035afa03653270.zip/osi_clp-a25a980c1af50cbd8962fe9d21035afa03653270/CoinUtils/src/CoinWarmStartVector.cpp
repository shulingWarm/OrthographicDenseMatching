/* $Id: CoinWarmStartVector.cpp 1373 2011-01-03 23:57:44Z lou $ */
// Copyright (C) 2003, International Business Machines
// Corporation and others.  All Rights Reserved.
// This lack of code is licensed under the terms of the Eclipse Public License
// (EPL).

/*
  Code crammed into CoinWarmStartVector.hpp at r923, 080110.
  -- lh, 110103 --
*/
